import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { Redirect, Tabs } from "expo-router";

import { useAuth } from "@/providers/AuthProvider";
import Login from "../../components/Login";
import Ionicons from "@expo/vector-icons/Ionicons";
import { Colors } from "../../constants/Colors";

const TabsLayout = () => {
	const { isAuthenticated } = useAuth();

	if (!isAuthenticated) {
		return <Login />;
	}
	return (
		<Tabs
			screenOptions={{ tabBarActiveTintColor: "green", headerShown: false }}
		>
			<Tabs.Screen
				name="mytrips"
				options={{
					headerTitle: "My Tripss",
					tabBarLabel: "My Trips",

					tabBarIcon: ({ color }) => (
						<Ionicons name="location-sharp" size={24} color={Colors.primary} />
					),
				}}
			/>
			<Tabs.Screen
				name="discover"
				options={{
					headerTitle: "Discover",
					tabBarLabel: "Discover ",

					tabBarIcon: ({ color }) => (
						<Ionicons name="globe-sharp" size={24} color={Colors.primary} />
					),
				}}
			/>
			<Tabs.Screen
				name="memories"
				options={{
					headerTitle: "Memories",
					tabBarLabel: "Memories ",

					tabBarIcon: ({ color }) => (
						<Ionicons name="journal" size={24} color={Colors.primary} />
					),
				}}
			/>
			<Tabs.Screen
				name="profile"
				options={{
					headerTitle: "Profile",
					tabBarLabel: "Profile",

					tabBarIcon: ({ color }) => (
						<Ionicons name="people-circle" size={24} color={Colors.primary} />
					),
				}}
			/>
		</Tabs>
	);
};

export default TabsLayout;

const styles = StyleSheet.create({});
