import { StyleSheet, Text, View } from "react-native";
import React from "react";

const Memories = () => {
	return (
		<View>
			<Text>memories</Text>
		</View>
	);
};

export default Memories;

const styles = StyleSheet.create({});
