import {
	FlatList,
	SafeAreaView,
	StyleSheet,
	Text,
	View,
	Image,
} from "react-native";
import React, { useState } from "react";
import { trips } from "@/constants/Trips";
import TripsListItem from "@/components/TripsListItem";
import Tab from "@/components/Tab";
import Header from "@/components/Header";
import { Ionicons } from "@expo/vector-icons";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import { Colors } from "@/constants/Colors";
import { ITrip } from "@/types";
import NotificationBell from "@/components/Notification";

const MyTripsList = () => {
	// const [tripList, setTripList] = useState(trips);

	const [tripList, setTripList] = useState<ITrip[]>(trips);

	const onSelectTripType = (selectedType) => {
		if (selectedType === "All") {
			setTripList(trips); // Show all trips
		} else {
			const filteredTrips = trips.filter((trip) => trip.type === selectedType);
			setTripList(filteredTrips); // Show filtered trips
		}
	};

	return (
		<SafeAreaView style={styles.container}>
			<View style={styles.myTripHeader}>
				<Image
					source={require("../../assets/images/splash-icon.png")}
					style={{ height: 40, width: 40, marginLeft: 16 }}
				/>
				<View>
					<FontAwesome name="search" size={24} color={Colors.primary} />
					{/* <View style={styles.dot}>
						<Text style={{ color: "#fff" }}>4+</Text>
					</View> */}
				</View>
			</View>

			<View style={styles.borderBottom} />
			{/* <Text>Your Trips Stats : {tripList.length}</Text> */}
			<Tab onSelect={onSelectTripType} />
			<FlatList
				data={tripList}
				keyExtractor={(item) => item.id}
				renderItem={({ item }: { item: ITrip }) => (
					<TripsListItem tripData={item} />
				)}
				contentContainerStyle={styles.listContainer}
			/>
		</SafeAreaView>
	);
};

export default MyTripsList;

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	listContainer: {
		padding: 16, // Add padding to the list container
	},

	myTripHeader: {
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "space-between",
		marginHorizontal: 16,
	},

	borderBottom: {
		borderColor: "gray",
		borderBottomWidth: 0.6,
		marginTop: 6,
		marginBottom: 32,
	},

	dot: {
		backgroundColor: "red",
		height: 14,
		width: 14,
		borderRadius: 6,
		position: "absolute",
		right: 0,
	},
});
