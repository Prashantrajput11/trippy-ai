import { SafeAreaView, StyleSheet, Text, View } from "react-native";
import React from "react";

const Discover = () => {
	return (
		<SafeAreaView>
			<Text>Discover</Text>
		</SafeAreaView>
	);
};

export default Discover;

const styles = StyleSheet.create({});
